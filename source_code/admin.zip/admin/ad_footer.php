  </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
   <script src="js/jquery.js"></script>
   <script src="js/sweetjs.js"></script>
  <link rel="stylesheet" href="css/datatable.css"/>
  <script type="text/javascript" src="js/datatable.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable({
        processing:true
    });
   
});</script>
    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>
	<script type="text/javascript" src="js/delete_choice.js"></script>
	<script type="text/javascript" src="js/import_order.js"></script>
	<script type="text/javascript" src="js/provicer_pulisher_choice.js"></script>
	<script type="text/javascript" src="js/update_order.js"></script>
    <!-- Flot Charts JavaScript -->
    <!--[if lte IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/flot/flot-data.js"></script>
	<script type="text/javascript" src="js/del_one.js"></script>
	<script type="text/javascript" src="js/dell_all.js"></script>
	<script type="text/javascript" src="js/finf_ad_product.js"></script>
	<script type="text/javascript" src="js/page_order.js"></script>
	<script type="text/javascript" src="js/find_product_import.js"></script>
</body>

</html>
