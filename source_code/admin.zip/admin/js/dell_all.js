
	// JavaScript Document
function delete_all()
{
	
	var kq=confirm("Bạn muốn tạo lại danh sách sản phẩm phiếu nhập?");
	if(kq==true)
	{
		window.location="ad_manipulation/car_delete_all.php";
	}
}
	// JavaScript Document