

   
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           <small class="text-uppercase"><i class="fa fa-desktop" aria-hidden="true"></i> Trang quản trị</small>
                        </h1>
                       
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="alert alert-info alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>  Chào mừng bạn đến với trang quản trị của Vì Tôi Đẹp.
                        </div>
                    </div>
                </div>
                <!-- /.row -->